DROP TABLE IF EXISTS tCustomers;
CREATE TABLE tbCustomers
(
	id INTEGER  PRIMARY KEY AUTOINTCREMENT,
	imie TEXT,
	nazwisko TEXT,
	adres TEXT,
);
DROP TABLE IF EXISTS tbOrders;
CREATE TABLE tbOrders
(
 id INTEGER  PRIMARY KEY AUTOINTCREMENT,
 customers_id INTEGER,
 data DATE,
);
ROP TABLE IF EXISTS tbSubscriptions;
CREATE TABLE tbSubscriptions
(
	id INTEGER  PRIMARY KEY AUTOINTCREMENT,
  description TEXT,
  price_per_month INTEGER,
  subscription_length TEXT
 );
