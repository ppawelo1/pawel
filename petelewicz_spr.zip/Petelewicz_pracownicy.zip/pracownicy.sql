DROP TABLE IF EXISTS pracownicy;
CREATE TABLE pracownicy(
    id_pracownika INTEGER PRIMARY KEY,
    imie VARCHAR(20),
    nazwisko VARCHAR(30),
    kod CHAR(6),
    miasto_z VARCHAR(20),
    ulica VARCHAR(20),
    data DATE,
    miasto_u VARCHAR(20)
    
);


DROP TABLE IF EXISTS stanowiska;
CREATE TABLE stanowiska(
    id_stanowiska INTEGER PRIMARY KEY AUTOINCREMENT,
    stanowisko VARCHAR(20)
);


DROP TABLE IF EXISTS place;
CREATE TABLE place(
    id_p INTEGER,
    id_s INTEGER,
    placa INTEGER,
    data_z DATE,
    FOREIGN KEY (id_p) REFERENCES pracownicy(id_pracownika),
    FOREIGN KEY (id_s) REFERENCES stanowiska(id_stanowiska)
);



DROP TABLE IF EXISTS kontakty;
CREATE TABLE kontakty(
    id_pracownika INTEGER,
    typ_k TINYINT,
    kontakt VARCHAR(15),
    uwagi VARCHAR(20),
    FOREIGN KEY (id_pracownika) REFERENCES pracownicy(id_pracownika)
);
