Uzupełnij poniższy dokument zastępując tekst "[wpisz nazwę]" nazwą
twojego (waszego) projektu w Bootstrap 4.

Przeczytaj [instrukcję realizacji zadania](doc/zadanie.md).

Po uzupełnieniu dokumentu usuń powyższe oraz niniejszy akapit
i zatwierdź zmiany używając komentarza "Aktualizacja README.md".

# [Wpisz nazwę projektu]
Szablon wykorzystujący framework Bootstrap v. 4 dla serwisu [wpisz nazwę]

## Użycie
[Tu umieść opis ewentualnych kroków wymaganych do wykorzystania szablonu]
